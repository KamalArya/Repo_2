package com.journaldev.spring.controller;

import org.springframework.test.web.servlet.*;
import org.springframework.test.web.servlet.setup.*;
import org.springframework.web.context.WebApplicationContext;
import org.testng.annotations.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.*;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;


public class HomeControllerTest {

	private MockMvc mockMvc;
	private HomeController homeController = new HomeController();

	@BeforeClass
	public void setup() {
		this.mockMvc = MockMvcBuilders.standaloneSetup(homeController).build();
	}

	@Test
	public void testLoad() throws Exception {
		String greet = "Hello !";
		this.mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk())
				.andExpect(model().attribute("greet", greet)).andExpect(view().name("home"));
	}

}
